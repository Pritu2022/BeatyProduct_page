function select () {
    return `<select  id="select">
    <option value="none">Select-Size</option>
    <option value="">Small</option>
    <option value="">Medium</option>
    <option value="">Large</option>
    <option value="">Extra Large</option>
</select>`
}

export default select;