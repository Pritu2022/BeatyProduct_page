function bottom () {
    return `
    <div id="a1">
    <a id="a" href="">Customer Service</a>
    <a id="b" href="">Order Status</a>
    <a id="b" href="">Guest returns</a>
    <a id="b" href="">Shipping & Return Policy</a>
    <a id="b" href="">Gift Cards</a>
    <a id="b" href="">FAQ</a>
    <a id="b" href="">Contact Us</a>
</div>

<div id="a1">
    <a id="a"  href="">About Us</a>
    <a id="b" href="">About Our Brand</a>
     <a id="b" href="">The Norby Club</a>
     <a id="b" href="">Store locator</a>
     <a id="b" href="">All Brand</a>
     <a id="b" href="">Careers</a>
     <a id="b" href="">Get Email Updates</a>
     <a id="b" href="">NordStrom Blog</a>
     <a id="b" href="">Nordy Podcaste</a>
</div>

<div id="a1">
    <a id="a" href="">NordStrom Rack & The Community</a>
    <a id="b" href="">Corporate Social Responsblity</a>
    <a id="b" href="">Dibersity Inclusion & Belonging</a>
    <a id="b" href="">Big Brothers Big Sisters</a>
    <a id="b" href="">Donate Clothes</a>
</div>

<div id="a1">
    <a id="a" href="">NordStrom card</a>
    <a id="b" href="">Apply For a NordStrom card</a>
    <a id="b" href="">Pay My Bill</a>
    <a id="b" href="">Manage My NordStrom Card</a>
</div>

<div id="a1">
    <a id="a" href="">NordStrom, Inc.</a>
    <a id="b" href="">NordStrom</a>
    <a id="b" href="">NordStrom Canada</a>
    <a id="b" href="">Trunk Club</a>
    <a id="b" href="">HauteLook</a>
    <a id="b" href="">Investor Relations</a>
    <a id="b" href="">Press Releases</a>
    <a id="b" href="">NordStrom Media Network</a>
</div>

<div id="a1">
    <a id="a" href="">Download Our App</a>
    <div id="a11">
        <img src="https://www.stylecraze.com/wp-content/themes/buddyboss-child/images/svg-image/facebook-f.svg" alt="">
        <img src="https://www.stylecraze.com/wp-content/themes/buddyboss-child/images/svg-image/pinterest-p.svg" alt="">
        <img src="https://www.stylecraze.com/wp-content/themes/buddyboss-child/images/svg-image/twitter.svg" alt="">
          <img src="https://www.stylecraze.com/wp-content/themes/buddyboss-child/images/svg-image/instagram.svg" alt="">
             <img src="https://www.stylecraze.com/wp-content/themes/buddyboss-child/images/svg-image/youtube.svg" alt="">
        
    </div>
</div>

<div id="a1">
   <img id="top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkoTYBscOrTwfkjVjHwwovRhDsUn9xNGyEMUAS-QxjdL0hJlLxRbid2Toie2J1ZGd48Y0&usqp=CAU" alt="">

</div>
`
}

export {bottom};