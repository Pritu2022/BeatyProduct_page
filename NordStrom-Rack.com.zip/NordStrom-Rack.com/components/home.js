function home(){
return `
<div id="menscloths">
    <ul type="none"> Home: Get Inspired
  <li>Mother's Day Gifts</li>
  <li>New Arrivals</li>
   <li> Best Sellers</li>
   <li> Bedding Under $50</li>
   <li>Home Decor Under $50</li>
   <li>Kitchen Appliances Under $100</li>
  <li>Rack Essentials</li>
  <li>Nordstrom Made</li>
  <li>Clearance</li>
  <li>Shop By Brand</li>
 </ul>
  </div>

  <div id="menscloths">
  <ul type="none">Bath
  <li>Bath Rugs & Mats</li>
  <li>Bath Towels</li>
  <li>Bathroom Decor</li>
  </ul>
  <br>
  <ul type="none">Bedding
  <li>Comforters & Duvet Inserts
  </li>
  <li>Duvet Covers</li>
  <li>Mattress Pads & Toppers
  </li>
  <li>Pillow Cases
  </li>
  <li>Pillows</li>
  <li>Quilts & Blankets</li>
  <li>Sheet Sets</li>
  <li>Throws</li>
  </ul>
  </div>


  <div id="menscloths">
  <ul type="none">Decor
  <li>Decorative Accessories</li>
  <li>Decorative Pillows</li>
  <li>Faux Plants & Stands</li>
  <li>Home Fragrances, Diffusers & Candles</li>
  <li>Lighting & Lamps</li>
  <li>Rugs & Doormats</li>
  <li>Stationery & Desk Accessories</li>
  <li>Window Treatments</li>


  </ul>
  <br>
  <ul type="none">Holiday Decorations</ul>
  <br>

  <ul type="none">Art & Wall Decor
  <li>Art by Color</li>
  <li>Art by Subject</li>
  <li>Art by Type</li>
  <li>Clocks</li>
  <li>Mirrors</li>
  </ul>
  </div>


  <div id="menscloths">
  <ul type="none">Kitchen & Tabletop
  <li>Bar Accessories</li>
  <li>Cookware & Bakeware</li>
  <li>Cutlery & Kitchen Knives</li>
  <li>Dinnerware & Flatware</li>
  <li>Drinkware & Glassware</li>
  <li>Serveware</li>
  <li>Small Appliances</li>
  </ul>
  <br>
  <ul type="none">Outdoor Living
  <li>Beach & Pool Accessories</li>
  <li>Outdoor Dining</li>

  </ul>
  <br>

  <ul type="none">Electronic & Tech Accessories
  <li>Headphones & Speakers</li>
  <li>Phone Cases</li>
  <li>Smart Home</li>
  <li>Smart Watches & Bands</li>
  </ul>
  </div>


  <div id="menscloths">
  <ul type="none">Storage & Cleaning
  <li>Bathroom Storage</li>
  <li>Bedroom & Closet Storage</li>
  <li>Kitchen Storage</li>
  <li>Laundry & Cleaning</li>
  <li>Storage Baskets & Bins</li>
  <li>Vacuum & Floor Care</li>
  </ul>
  <br>
  <ul type="none">Pet Accessories</ul>
  <br>

  <ul type="none">Games</ul>
  <br>

  <ul type="none">Luggage & Travel</ul>
  </div>


`



}
export { home }; 