function gifts(){
return `
<div id="menscloths">
    <ul type="none"> <a href="../Beauty_page/mothersgift.html">Gifts: Get Inspired</a>
  <li>Gift Cards</li>
  <li>Wish List</li>
 </ul>
  </div>

  <div id="menscloths">
    <ul type="none"> Mother's Day Gifting
  <li>Gifts for Mom Under $25</li>
  <li>Gifts for Mom Under $50</li>
  <li>Unique Gifts for Mom</li>
  <li>Luxe & Designer for Mom</li>
  <li>Jewelry & Watches for Mom</li>
  <li>Wellness Gifts for Mom</li>
  <li>Home Gifts for Mom</li>
  <li>Dressed Up Styles for Mom</li>
  <li>Activities for Mom: At-Home Spa</li>
  <li>Activities for Mom: Cooking & Cocktails</li>

 </ul>
  </div>

  <div id="menscloths">
  <ul type="none">Everyday Gifting
  <li>Gifts for Her</li>
  <li>Gifts for Him</li>
  <li>Gifts for Kids</li>
  <li>Gifts for Home</li>
  <li>Gifts Under $25</li>
  <li>Gifts Under $50</li>
  <li>Gifts Under $100</li>
  </ul>
  </div>

  <div id="menscloths">
  <ul type="none">Gifts by Occasion
  <li>Baby Shower Gifts</li>
  <li>Wedding Gifts</li>
  </ul>
  </div>

`


}
export { gifts }