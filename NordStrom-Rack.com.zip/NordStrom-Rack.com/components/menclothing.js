function mens(){
return `
<div id="menscloths">
    <ul type="none"> Men: Get Inspired
  <li>Mother's Day Gifts</li>
  <li><a href="../Men/activewear.html">New Arrivals</a></li>
   <li> <a href="../Men/activewear.html">Best Sellers</a></li>
   <li><a href="../Men/activewear.html">Designer Brands</a></li>
   <li><a href="../Men/activewear.html">Contemporary Brands</a></li>
   <li><a href="../Men/activewear.html">Graphic Tees Under $25</a></li>
  <li><a href="../Men/activewear.html">Denim Under 50$</a></li>
  <li><a href="../Men/activewear.html">Swim & sun under 50$</a></li>
  <li><a href="../Men/activewear.html">Snikkers under 50$</a></li>
  <li><a href="../Men/activewear.html">Wedding Shop-</a></li>
  <li><a href="../Men/activewear.html">Shop By Occasion</a></li>
  <li><a href="../Men/activewear.html">Nike for the Family</a></li>
  <li><a href="../Men/activewear.html">Rack Essentials</a></li>
  <li><a href="../Men/activewear.html">Shop By Brands</a></li>
  <li><a href="../Men/activewear.html">NordStrom Made</a></li>
  <li><a href="../Men/activewear.html">Clearance</a></li>
 </ul>
  </div>
  <div id="menscloths">
  <ul type="none"><a href="../Men/activewear.html">Clothing</a>
  <li><a href="../Men/activewear.html">Active Wear</a></li>
  <li><a href="../Men/activewear.html">Best Blazzers</a></li>
  <li><a href="../Men/activewear.html">Coats & Jackets</a></li>
  <li><a href="../Men/activewear.html">Dresses</a></li>
  <li><a href="../Men/activewear.html">Jeans & denim</a></li>
  <li><a href="../Men/activewear.html">Jumpsuits & Rompers</a></li>
  <li><a href="../Men/activewear.html">Lingery,Hosiery & ShapeWear</a></li>
  <li><a href="../Men/activewear.html">LoungWear</a></li>
  <li><a href="../Men/activewear.html">Pants & Laggins</a></li>
  <li><a href="../Men/activewear.html">Shorts</a></li>
  <li><a href="../Men/activewear.html">Shirts</a></li>
  <li><a href="../Men/activewear.html">Sleepwear & Robes</a></li>
  <li><a href="../Men/activewear.html">Sweaters</a></li>
  <li><a href="../Men/activewear.html">Sweetshirts & Hoodies</a></li>
  <li><a href="../Men/activewear.html">SwimSuits & Cover-ups</a></li>
  <li><a href="../Men/activewear.html">Tops</a></li>
  <li><a href="../Men/activewear.html">Plus-size</a></li>

  </ul>
  </div>

  <div id="menscloths">
  <ul type="none"><a href="../Men/shoes.html">Shoes</a>
  <li><a href="../Men/shoes.html">Athletic & Running</a></li>
  <li><a href="../Men/shoes.html">Boat Shoes</a></li>
  <li><a href="../Men/shoes.html">Boots</a></li>
  <li><a href="../Men/shoes.html">Comfort</a></li>
  <li><a href="../Men/shoes.html">Dress Shoes</a></li>
  <li><a href="../Men/shoes.html">Loafers & Slip-Ons</a></li>
  <li><a href="../Men/shoes.html">Oxford & Derbis</a></li>
  <li><a href="../Men/shoes.html">Sandals & Flip-Flops</a></li>
  <li><a href="../Men/shoes.html">Slippers</a></li>
  <li><a href="../Men/shoes.html">Snkkers</a></li>
  <li><a href="../Men/shoes.html">Extended Shoe sizes & Widths</a></li>
  
  </ul>
  </div>
  <div id="menscloths">
  <ul type="none">Young Adults
  <li>Accessories</li>
  <li>Clothing</li>
  <li>Shoes</li>
  </ul>
  <br><br>
  <ul type="none">Accessories
  <li>Bags & Backpacks </li>
  <li>Belts & Suspenders</li>
  <li>Hats</li>
  <li>Jewelry</li>
  <li>Ties & Pocket Squares</li>
  <li>Wallets & Card Cases</li>

  </ul>
  <br>
  <ul type="none">Sunglasses & Eyewear</ul>
  <br>
  <ul type="none">Watches</ul>
  <br>

  <ul type="none"></ul>
  <br>

  <ul type="none">Luggage & travel</ul>
  <br>

  <ul type="none">Grooming & Cologne</ul>
  </div>

  <div id="menscloths">
  <ul type="none">Activewear
  <li>Jackets</li>
  <li>Shirts</li>
  <li>Shorts</li>
  <li>Sweatpants & Joggers </li>
  <li>Sweatshirts & Hoodies</li>
  <li>Tanks</li>
  </ul>
  <br><br>
  <ul type="none">Active Shoes
  <li>Hiking & Trail</li>
  <li>Running</li>
  <li>Training</li>
  <li>Walking</li>

  </ul>

   <br>
   <ul>Athletic Gear & Equipment</ul>
  </div>


`


}

export { mens };