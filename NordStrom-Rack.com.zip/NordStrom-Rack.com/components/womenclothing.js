function womensclothing(){
    return `
    
    <div id="womenscloths">
    <ul type="none"> <a href="../project_nordstrom/women.html">Women: Inspired</a>
  <li><a href="../project_nordstrom/women.html">Mothe's Day Gift</a></li>
  <li><a href="../project_nordstrom/women.html">New Arrivals</a></li>
   <li><a href="../project_nordstrom/women.html">Best Sellers</a></li>
   <li><a href="../project_nordstrom/women.html">Designer Brands</a></li>
   <li><a href="../project_nordstrom/women.html">Contemporary Brands</a></li>
   <li><a href="../project_nordstrom/women.html">Trend Brands</a></li>
  <li><a href="../project_nordstrom/women.html">Dresses Under $50</a></li>
  <li><a href="../project_nordstrom/women.html">Denim Under $50</a></li>
  <li><a href="../project_nordstrom/women.html">Swim & sun Under $50</a></li>
  <li><a href="../project_nordstrom/women.html">Sandals Under $50</a></li>
  <li><a href="../project_nordstrom/women.html">Wedding shop</a></li>
  <li><a href="../project_nordstrom/women.html">Shop By Occasion</a></li>
  <li><a href="../project_nordstrom/women.html">Shop By Trend</a></li>
  <li><a href="../project_nordstrom/women.html">Nike For The Family</a></li>
  <li><a href="../project_nordstrom/women.html">Rack Essentials</a></li>
  <li><a href="../project_nordstrom/women.html">Shop By Brands</a></li>
 </ul>
  </div>
  <div id="womenscloths">
  <ul type="none"><a href="../project_nordstrom/women.html">Clothing</a>
  <li><a href="../project_nordstrom/women.html">Activewear</a></li>
  <li><a href="../project_nordstrom/women.html">Blazzers</a></li>
  <li><a href="../project_nordstrom/women.html">Coats & Jakcets</a></li>
  <li><a href="../project_nordstrom/women.html">Dresses</a></li>
  <li><a href="../project_nordstrom/women.html">Jeans & Denim</a></li>
  <li><a href="../project_nordstrom/women.html">Jumpsuits & Rumpers</a></li>
  <li><a href="../project_nordstrom/women.html">Lingerie,Hosiery & Shapewear</a></li>
  <li><a href="../project_nordstrom/women.html">Loungewear</a></li>
  <li><a href="../project_nordstrom/women.html">Pants & Leggins</a></li>
  <li><a href="../project_nordstrom/women.html">Shorts</a></li>
  <li><a href="../project_nordstrom/women.html">Shirts</a></li>
  <li><a href="../project_nordstrom/women.html">Sleepwear & Robes</a></li>
  <li><a href="../project_nordstrom/women.html">Sweaters</a></li>
  <li><a href="../project_nordstrom/women.html">Sweetshirts & Hoodies</a></li>
  <li><a href="../project_nordstrom/women.html">Swwimsuits & Cover-Ups</a></li>
  <li><a href="../project_nordstrom/women.html">Tops</a></li>
  <li><a href="../project_nordstrom/women.html">Plus-size</a></li>

  </ul>
  </div>
   
  <div id="womenscloths">
  <ul type="none"><a href="../project_nordstrom/women.html">Shoes</a>
  <li><a href="../project_nordstrom/women.html">Athletic 7 Running</a></li>
  <li><a href="../project_nordstrom/women.html">Boots & Booties</a></li>
  <li><a href="../project_nordstrom/women.html">Clogs</a></li>
  <li><a href="../project_nordstrom/women.html">Comfort</a></li>
  <li><a href="../project_nordstrom/women.html">Esspadriless</a></li>
  <li><a href="../project_nordstrom/women.html">Flats</a></li>
  <li><a href="../project_nordstrom/women.html">Flip-Flops & Slides</a></li>
  <li><a href="../project_nordstrom/women.html">Heels</a></li>
  <li><a href="../project_nordstrom/women.html">Loafers & Oxfords</a></li>
  <li><a href="../project_nordstrom/women.html">Mules</a></li>
  <li><a href="../project_nordstrom/women.html">Rain Boots</a></li>
  <li><a href="../project_nordstrom/women.html">Sandals</a></li>
  <li><a href="../project_nordstrom/women.html">Slippers</a></li>
  <li><a href="../project_nordstrom/women.html">Sneekers</a></li>
  <li><a href="../project_nordstrom/women.html">Wedges</a></li>
  <li><a href="../project_nordstrom/women.html">Extended Shoe Sizes 7 Widths</a></li>
  </ul>
  </div>
  <div id="womenscloths">
  <ul type="none"><a href="../project_nordstrom/women.html">Young adults</a>
  <li><a href="../project_nordstrom/women.html">Accesories</a></li>
  <li><a href="../project_nordstrom/women.html">Clothing</a></li>
  <li><a href="../project_nordstrom/women.html">Shoes</a></li>
  </ul>
  <br><br>
  <ul type="none"><a href="../project_nordstrom/women.html">HandBags</a>
  <li><a href="../project_nordstrom/women.html">Designer Bags</a></li>
  </ul>
  <br>
  <ul type="none"><a href="../project_nordstrom/women.html">Sunglasses & Eyewear</a></ul>
  <br>

  <ul type="none"><a href="../project_nordstrom/women.html">Jewelery</a></ul>
  <br>

  <ul type="none"><a href="../project_nordstrom/women.html">Watches</a></ul>
  <br>

  <ul type="none"><a href="../project_nordstrom/women.html">Accesories</a></ul>
  <br>

  <ul type="none"><a href="../project_nordstrom/women.html">Luggage & Travel</a></ul>
  <br>

  <ul type="none"><a href="../project_nordstrom/women.html">Beauty</a></ul>
  </div>
  

  <div id="womenscloths">
  <ul type="none"><a href="../project_nordstrom/women.html">Activewear</a>
  <li><a href="../project_nordstrom/women.html">Crops & Capris</a></li>
  <li><a href="../project_nordstrom/women.html">Jackets</a></li>
  <li><a href="../project_nordstrom/women.html">Leggings</a></li>
  <li><a href="../project_nordstrom/women.html">Shirts & Tees</a></li>
  <li><a href="../project_nordstrom/women.html">Shorts & Sckirts</a></li>
  <li><a href="../project_nordstrom/women.html">Sports Bras</a></li>
  <li><a href="../project_nordstrom/women.html">Sweetpants & Joggers</a></li>
  <li><a href="../project_nordstrom/women.html">Sweetshirts & Hoodies</a></li>
  <li><a href="../project_nordstrom/women.html">Tanks</a></li>
  </ul>
  <br><br>
  <ul type="none"><a href="../project_nordstrom/women.html">Active Shoes</a>
  <li><a href="../project_nordstrom/women.html">Hiking & Trails</a></li>
  <li><a href="../project_nordstrom/women.html">Running</a></li>
  <li><a href="../project_nordstrom/women.html">Training</a></li>
  <li><a href="../project_nordstrom/women.html">Walking</a></li>

  </ul>

   <br>
   <ul><a href="../project_nordstrom/women.html">Athletic Gear & Equipment</a></ul>
  </div>
  
    `
}
export { womensclothing };