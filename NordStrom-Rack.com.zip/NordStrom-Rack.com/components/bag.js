function bag(){
return `
<div id="menscloths">
  <ul type="none">Bags & Accessories: Get Inspired
  <li>Mother's Day Gifts</li>
<li>New Arrivals</li>
<li>Best Sellers</li>
<li>Handbags Under $100</li>
<li>Designer Sunglasses Under $100</li>
<li>Nordstrom Made</li>
<li>Women's Accessories Clearance</li>
<li>Men's Accessories Clearance</li>
  </ul>
  </div>


  <div id="menscloths">
  <ul type="none">Shop By Brand
  <li>Bony Levy</li>
  <li>Gucci Sunglasses</li>
  <li>Kate Spade New York</li>
  <li>Marc Jacobs</li>
  <li>Ray-Ban</li>
  </ul>
  <br>
  <ul type="none">Designer
  <li>Designer Accessories</li>
  <li>Designer Handbags</li>
  <li>Designer Sunglasses & Eyewear</li>

  </ul>
  </div>


<div id="menscloths">
<ul type="none">Handbags
<li>Backpacks</li>
<li>Beach & Straw Bags</li>
<li>Bucket Bags</li>
<li>Clutches & Pouches</li>
<li>Crossbody Bags</li>
<li>Designer Bags</li>
<li>Fanny Packs & Belt Bags</li>
<li>Mini Bags</li>
<li>Satchels</li>
<li>Shoulder Bags</li>
<li>Totes</li>
<li>Wallets</li>
 </ul>
 <br>
 <ul type="none">Luggage & Travel</ul>
 <br>
<ul>Tech Accessories</ul>
<br>
<ul>Sunglasses & Eyewear</ul>
  </div>

  <div id="menscloths">
  <ul type="none">Jewelry
  <li>Bracelets</li>
  <li>Earrings</li>
  <li>Necklaces</li>
  <li>Rings</li>
  <br><br>
  <li>14K Gold Jewelry</li>
  <li>Diamond Jewelry</li>
  <li>Gold Jewelry</li>
  <li>Rose Gold Jewelry</li>
  <li>Sterling Silver Jewelry</li>
  </ul>
  
  <br><br>
  <ul type="none">Fine Jewelry
  <li>Bracelets</li>
  <li>Earrings</li>
  <li>Necklaces</li>
  <li>Rings</li>
  <li>Watches</li>
  </ul>

  </div>



  <div id="menscloths">
  <ul type="none">Women's Accessories
  <li>Belts</li>
  <li>Hair Accessories</li>
  <li>Hats</li>
  <li>Ponchos, Kimonos & Capes</li>
  
  <li>Sarongs, Caftans & Cover-Ups</li>
  <li>Scarves</li>
  <li>Winter Accessories</li>
  </ul>
  
  <br><br>
  <ul type="none">Men's Accessories
  <li>Bags & Backpacks</li>
  <li>Belts & Suspenders</li>
  <li>Hats</li>
  <li>Wallets & Card Cases</li>
  <li>Winter Accessories</li>
  </ul>

  </div>




`
}
export { bag };




