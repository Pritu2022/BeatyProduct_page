
function women(){
    return `
    <div id="women">
    <ul type="none"> Women
                                <li>Clothing</li>
                                <li>Shoes</li>
                                <li>Handbags</li>
                                <li>Sunglasses & Eyewear</li>
                                <li>Jewelry</li>
                                <li>watches</li>
                                <li>Accessories</li>
                            </ul>
                           </div>
                           <div id="men">
                            <ul type="none"> Men
                                <li>Clothing</li>
                                <li>Shoes</li>
                                <li>watches</li>
                                <li>Accessories</li>
                            </ul>
                            <br>
                            <br>
                            <ul>Designer</ul>
                           </div>
                           <div id="kids">
                            <ul type="none"> Kids
                                <li>Girls' Clothing</li>
                                <li>Girls' Shoes</li>
                                <li>Boys' Clothing</li>
                                <li>Boys' Shoes</li>
                                <li>Kids' Shoes</li>
                                <li>Baby Clothing & Shoes</li>
                            </ul>
                            <br>
                            <br>
                            <ul>Activewear</ul>
                           </div>
                           <div id="Home">
                            <ul type="none"> Home
                                <li>Art & Wall Decor</li>
                                    <li>Bath</li>
                                    <li>Bedding</li>
                                    <li>Decor</li>
                                    <li>Electronic & Tech Accessories</li>
                                    <li> Kitchen & Tabletop</li>
                                    <li> Storage & Cleaning</li>
                               
                            </ul>
                            <br>
                            <ul>Beauty
                                <li>Makeup</li>
                                <li>Skin Care</li>
                            </ul>
                           </div>
                           <div id="imge">
                               <img src="https://n.nordstrommedia.com/id/50c6a4af-0659-49b6-994b-3434244e2267.png"/>
                               <br><br>
                               <a href="#">Shop Now</a>        
                            </div>
    `
}

export { women };