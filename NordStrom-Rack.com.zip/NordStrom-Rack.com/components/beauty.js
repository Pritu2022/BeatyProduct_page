function beauty(){
return `
<div id="menscloths">
    <ul type="none"><a href="../Beauty_page/getinspired.html"> Beauty: Get Inspired</a>
  <li><a href="../Beauty_page/getinspired.html"> Mother's Day gift</a></li>
  <li><a href="../Beauty_page/getinspired.html">New Arrivals</a></li>
   <li> <a href="../Beauty_page/getinspired.html"> Best sellers</a></li>
   <li> <a href="../Beauty_page/getinspired.html"> Presstigue Beauty</a></li>
   <li><a href="../Beauty_page/getinspired.html">Natural Beauty</a></li>
   <li><a href="../Beauty_page/getinspired.html"> Beauty Under 25$</a></li>
  <li><a href="../Beauty_page/getinspired.html"> Hair-Care Under 25$</a></li>
  <li><a href="../Beauty_page/getinspired.html"> Skin Care Under 20$</a></li>
  <li><a href="../Beauty_page/getinspired.html"> MakeUp Under 20$</a></li>
  <li><a href="../Beauty_page/getinspired.html"> Beauty Gifts & Sets</a></li>
  <li><a href="../Beauty_page/getinspired.html"> Travel & Mini Sizes</a></li>
  <li><a href="../Beauty_page/getinspired.html"> Clearance</a></li>
 </ul>
  </div>

  <div id="menscloths">
  <ul type="none"><a href="../Beauty_page/Allmakeup.html">Shop By Brand</a>
  <li><a href="../Beauty_page/Allmakeup.html">Charotte Teelborry</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Clinique</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Drybar</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">L'Occitane</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">M.A.C. Cosmetics</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Mario Badescu</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Nudesticks</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Sheisido</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">To Faced</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Urban Decay</a></li>
  </ul>
  </div>

  <div id="menscloths">
  <ul type="none"><a href="../Beauty_page/Allmakeup.html">Makeup</a>
  <li><a href="../Beauty_page/Allmakeup.html">Blush,Bronzer & Highlighter</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Brushes & Tools</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Concealer & Foundation</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Eye MakeUp</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Eyebrows</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Eyeshadow & Eyeliner</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Gifts & Sets</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Lipstics,Lip-glose & Liner</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">MAscare & Lashes</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Pallets</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Nail Polish & Care</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Powder & Setting Sprays</a></li>
  <li><a href="../Beauty_page/Allmakeup.html">Primer</a></li>
  </ul>
  </div>

  <div id="menscloths">
  <ul type="none"><a href="../Beauty_page/Allskincare.html">Skin Care</a>
  <li><a href="../Beauty_page/Allskincare.html">Cleansers</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Exfoliator</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Eye Creams & Treatments</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Face Meets & Toners</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Face Moisturizors</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Facial Masks</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Gifts & Sets</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Lip Balms  & Treatments</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Make Up Removers</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Serums</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Sunscreens</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Tools & Devices</a></li>
  <li><a href="../Beauty_page/Allskincare.html">Bath & Body</a></li>
  </ul>
  </div>

  <div id="menscloths">
  <ul type="none"><a href="../Beauty_page/AllhairCare.html">Hair Care</a>
  <li><a href="../Beauty_page/AllhairCare.html">Hair & Scalp Treatments</a></li>
  <li><a href="../Beauty_page/AllhairCare.html">Hair Dryers & Styling Tools</a></li>
  <li><a href="../Beauty_page/AllhairCare.html">Eye Creams & Treatments</a></li>
  <li><a href="../Beauty_page/AllhairCare.html">Hair Styling Products</a></li>
  <li><a href="../Beauty_page/AllhairCare.html">Shampoo & Conditioner</a></li>
  </ul>
  <br>
  <ul type="none"><a href="../Beauty_page/Allfragrance.html">Fragrance</a>
  <li><a href="../Beauty_page/Allfragrance.html">Candles & Defusers</a></li>
  <li><a href="../Beauty_page/Allfragrance.html">Designer Fragrance</a></li>
  <li><a href="../Beauty_page/Allfragrance.html">Gifts & Sets</a></li>
  <li><a href="../Beauty_page/Allfragrance.html">Perfume</a></li>
  </ul>
 
  <br>
  <ul type="none"><a href="../Beauty_page/Alltools.html">Tools, Brushes & Makeup Bags</a>
  <li><a href="../Beauty_page/Alltools.html">Bath & Body Tools</a></li>
  <li><a href="../Beauty_page/Alltools.html"> Hair Styling Tools</a></li>
  <li><a href="../Beauty_page/Alltools.html">Makeup Brushes,Tools & Bags</a></li>
  <li><a href="../Beauty_page/Alltools.html">Skin Care Tools</a></li>
  </ul>
  <br>
  <ul type="none"><a href="../Beauty_page/Allmensgrooming.html">Men's Grooming & Cologne</a></ul>
  </div>

`

}

export { beauty }