function kids(){
return `
<div id="menscloths">
    <ul type="none"> Kids: Get Inspired
  <li>Mother's Day Gifts </li>
  <li> New Arrivals</li>
   <li>Best Sellers</li>
   <li>  Sandals Under $20</li>
   <li> Sneakers Under $30</li>
   <li>Nike for the Family</li>
  <li> Swim Shop</li>
  <li>Disney Shop</li>
  <li>Z by Zella for the Family</li>
  <li>Rack Essentials</li>
  <li>Baby Shower Gifts</li>
  <li>Shop by Occasion</li>
  <li>Shop By Brand</li>
  <li>Nordstrom Made</li>
  <li>Clearance</li>
 </ul>
  </div>

  <div id="menscloths">
  <ul type="none">Girls' Clothing
  <li>Baby Girl (Sizes 0-24M)</li>
  <li>Toddler Girls (Sizes 2T-4T)</li>
  <li>Girls (Sizes 4-6x)</li>
  <li>Girls (Sizes 7-16)</li>
  <li>Tween Girls</li>
  <li>Accessories</li>
  <li>Activewear</li>
  <li>Coats & Jackets</li>
  <li>Dresses & Rompers</li>
  <li>Jeans</li>
  <li>Pajamas & Robes</li>
  <li>Pants & Leggings</li>
  <li>Shorts</li>
  <li>Skirts</li>
  <li>Swimsuits & Cover-Ups</li>
  <li>Tops</li>
  <li>Underwear, Socks & Bras</li>

  </ul>
  </div>
 
  <div id="menscloths">
  <ul type="none">Boys Clothing
  <li>Baby Boy (Sizes 0-24M)</li>
  <li>Toddler Boys (Sizes 2T-4T)</li>
  <li>Boys (Sizes 4-7)</li>
  <li> Boys (Sizes 8-20)</li>
  <li>Accessories</li>
  <li>Activewear</li>
  <li>Coats & Jackets</li>
  <li>Jeans</li>
  <li>Pajamas & Robes</li>
  <li>Pants</li>
  <li> Sets</li>
  <li>Shirts & Tops</li>
  <li>Shorts</li>
  <li>Suits & Separates</li>
  <li>Swim Trunks & Rashguards</li>
  <li>T-Shirts</li>
  <li>Underwear & Socks</li>

  </ul>
  </div>

  <div id="menscloths">
  <ul type="none">kids shoes
  <li>Kids' Shoes</li>
  <li>Baby (Sizes 0-4)</li>
  <li>Toddler (Sizes 4.5-12)</li>
  <li>Little Kid (Sizes 12.5-3)</li>
  <li>Big Kid (Sizes 3.5-7)</li>


  </ul>

<br>
<ul type="none">Girls' Shoes
  <li>Baby (Sizes 0-4)</li>
  <li>Toddler (Sizes 4.5-12)</li>
  <li>Little Kid (Sizes 12.5-3)</li>
  <li>Big Kid (Sizes 3.5-7)</li>

  </ul>
<br>
<ul type="none">Boys' Shoes
  <li>Baby (Sizes 0-4)</li>
  <li>Toddler (Sizes 4.5-12)</li>
  <li>Little Kid (Sizes 12.5-3)</li>
  <li>Big Kid (Sizes 3.5-7)</li>

  </ul>
  </div>

  <div id="menscloths">
  <ul type="none">Baby Clothing & Shoes
  <li>Baby Girl</li>
  <li>Baby Boy</li>
  <li>Baby Shoes</li>
  <li>Baby Gear & Essentials</li>
  <li>Baby Shower Gifts</li>
  <li>Toys</li>

  </ul>
  </div>

`


}
export { kids };
















